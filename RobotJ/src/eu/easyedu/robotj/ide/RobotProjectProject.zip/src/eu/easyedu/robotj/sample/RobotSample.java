package eu.easyedu.robotj.sample;

import eu.easyedu.robotj.*;
import eu.easyedu.robotj.canvas.Canvas;
import eu.easyedu.robotj.project.RobotProject;

/**
 *
 * @author hlavki
 */
public class RobotSample extends RobotProject {

    private final Canvas canvas;

    public RobotSample(Canvas canvas) {
        super("PrdProject");
        this.canvas = canvas;
    }

    public void runProject() {
        Robot robot = new Robot("r1", canvas, 150, 150);
        robot.setVisible(true);
        for (int i = 0; i < 4; i++) {
            robot.forward(100);
            robot.right(90);
        }
    }
}
